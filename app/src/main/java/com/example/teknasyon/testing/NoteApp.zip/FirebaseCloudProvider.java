package com.example.teknasyon.testing;

import com.google.firebase.messaging.FirebaseMessagingService;

public class FirebaseCloudProvider extends FirebaseMessagingService
{
    @Override
    public void onNewToken(String s)
    {
        super.onNewToken(s);
    }

}//end class